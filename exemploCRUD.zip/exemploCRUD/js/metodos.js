/* 
 * Arquivo contendo meus métodos (funções) personalizados
 
$('#btnApagar').confirmation('show');  // tentativa de ativar o toggle do botao apagar
*/
function plotarGraficos(tipo,container,titulo){ 
    // utilizado com o CanvasJS
    // para funcionar certifique-se que esse JS seja inserido no início
    // da pagina web e não no final como sugere o padrão web.
    var desenho = new CanvasJS.Chart(container,
	{
            animationEnabled: true,
            theme: "theme2",
            //exportEnabled: true,
            title:{
                    text: titulo
                    },
            animatedEnabled: false,
            data: [
            {
             type: tipo, //change type to bar, line, area, pie, etc
             dataPoints: [
                        { x: 10, y: 71 },
                        { x: 20, y: 55 },
                        { x: 30, y: 50 },
                        { x: 40, y: 65 },
                        { x: 50, y: 95 },
                        { x: 60, y: 68 },
                        { x: 70, y: 28 },
                        { x: 80, y: 34 },
                        { x: 90, y: 14 }
                         ]
            }
                  ]
	});

	desenho.render();
}
