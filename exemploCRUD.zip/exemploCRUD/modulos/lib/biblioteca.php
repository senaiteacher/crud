<?php
/* 
 * Documento contendo métodos gerais utilizado pelos aplicações.
 * Aqui é um bom lugar para você colocar todas as funções personalizadas
 * que você criar.
 * Esse arquivo deve ser incorporado pelo comando INCLUDE como a primeira linha 
 * dos seus arquivos PHP.
 */

// função para validar os dados transmitidos pelos formulários para evitar uso por Hackers.
// Mais informações acesse: http://www.w3schools.com/php/php_form_validation.asp

function validarEnvio($data) {
  $data = trim($data);               // Limpa espaços em branco
  $data = stripslashes($data);       // remove barras
  $data = htmlspecialchars($data);   // remove caracteres especiais
  return $data;                      // retona variável "limpa"
}

/*
 * função para mostrar a descrição baseada em um número de erro.
 * A função também mostra o último erro ocorrido no acesso ao MySQL.
 */
function executarSQL($query) {
    include("../../acesso/conexao.php");
    $cursor = mysqli_query($conexao,$query);
    if ($cursor) {
        return $cursor;
    }else{
        return false;
    }
    mysqli_close($conexao);   // fecha a conexão
}


function mostrarErro($tipo) {
    
}

function ativarBoots() {
   echo'<meta charset="UTF-8">';
   echo'<meta name="viewport" content="width=device-width, initial-scale=1.0">';
   echo'<link rel="stylesheet" href="/exemplo/css/bootstrap.min.css">';
   echo'<link rel="stylesheet" href="/exemplo/css/bootstrap-responsive.min.css">';
   echo'<link rel="stylesheet" href="/exemplo/css/bootstrap-theme.min.css">';
   echo'<link rel="stylesheet" href="/exemplo/css/estilos.css">';
   echo'<script src="/exemplo/js/jquery.min.js"></script>';
   echo'<script src="/exemplo/js/bootstrap.min.js"></script>';
   echo'<script src="/exemplo/js/metodos.js"></script>';
   echo'<script src="/exemplo/js/bootstrap-confirmation.js"></script>';
}


?>