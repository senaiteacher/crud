var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });

function preload() {
    game.load.image('sky', '../assets/galaxy2.jpeg');
    game.load.image('ship', '../assets/thrust_ship2.png');
    game.load.image('bullet', '../assets/bullet0.png');
    game.load.image('ufo', '../assets/ufo.png');

}

var player;
var bullets;
var ufos;

var cursors;
var fireButton;

var bulletTime = 0;
var bullet;

function create() {

    game.physics.startSystem(Phaser.Physics.ARCADE);
    //  A simple background for our game
    game.add.sprite(0, 0, 'sky');
    
    bullets = game.add.physicsGroup();
    bullets.createMultiple(32, 'bullet', false);
    bullets.setAll('checkWorldBounds', true);
    bullets.setAll('outOfBoundsKill', true);

    player = game.add.sprite(400, 550, 'ship');
    game.physics.arcade.enable(player);
    player.body.collideWorldBounds = true;

    cursors = game.input.keyboard.createCursorKeys();
    fireButton = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
    
    ufos = game.add.group();
    ufos.enableBody = true;
    
    for (var i = 0; i < 12; i++)
    {
      
        //  Create a ufo inside of the 'ufos' group
        var ufo = ufos.create(i * 70, i+2, 'ufo');

        //  Let gravity do its thing
        ufo.body.gravity.y = 2;

        //  This just gives each star a slightly random bounce value
        ufo.body.bounce.y = 0.7 + Math.random() * 0.2;
    }

}
function update () {

    player.body.velocity.x = 0;

    if (cursors.left.isDown)
    {
        player.body.velocity.x = -600;
    }
    else if (cursors.right.isDown)
    {
        player.body.velocity.x = 600;
    }

    if (fireButton.isDown)
    {
        fireBullet();
    }

}

function fireBullet () {

    if (game.time.time > bulletTime)
    {
        bullet = bullets.getFirstExists(false);

        if (bullet)
        {
            bullet.reset(player.x + 6, player.y - 12);
            bullet.body.velocity.y = -600;
            bulletTime = game.time.time + 100;
        }
    }

}