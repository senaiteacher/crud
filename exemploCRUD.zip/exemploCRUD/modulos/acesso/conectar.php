<?php
/* 
 * Este arquivo realiza a primeira conexão na entrada da página.
 * Se a conexao falhar ele redirecionará para a página de configuração
 * do servidor do Banco de Dados e irá realizar a criação das Bases 
 * automaticamente, de acordo com o script do arquivo "estrutura.sql"
 * na pasta "database".
 */

/* 1. verifica as configurações do seu servidor no arquivo criptografado.
 * 2. se não existir ele criar o arquivo txt com as configurações definidas 
 * nas variáveis.
 * 3. Baseada nessas informações ele irá criar automaticamente a Base de Dados.
 */

// Edite aqui as configurações de acesso do seu servidor.
$servidor ='localhost';
$usuario ='root';
$senhaDB ='25b7bbc1';
$database ='senaidb';

$arquivo = fopen("../acesso/admin.ini", "w+");      // Abre ou cria arquivo TXT
$escreve = fwrite($arquivo,$servidor);              // grava no arquivo TXT
fclose($arquivo);   

?>

