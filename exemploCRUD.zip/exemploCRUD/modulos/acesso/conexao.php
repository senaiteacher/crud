<?php
$servidor ='localhost';
$usuario ='root';
$senha ='25b7bbc1';
$database ='senaidb';

$conexao = mysqli_connect($servidor,$usuario,$senha,$database);

if (!$conexao){
	die("Erro ao conectar:".mysql_error());
}

?>