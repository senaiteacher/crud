<?php

// Usamos o comando $_GET[] para receber os dados enviados do formulario
// Usamos o comando trim() para limpar os espaços das informações.
$nome = trim($_GET["nomeCompleto"]);
$email = trim($_GET["email"]);
$login = trim($_GET["login"]);
$senhaI = trim($_GET["senha"]);
// para criar saida em html utiliza-se o comando echo.
// echo $nome."<BR>".$email."<BR>".$login."<BR>".$senha;
/* para conectar com o MySQL usa-se mysql_connect.
  Sequencia sugerida:
  1. Conectar com o MySQL.
  2. Selecionar Database.
  3. Criar string com o comando SQL.
  4. Enviar o comando.
  5. Avaliar o resultado da operação.
  6. fechar a conexão.
  7. retornar para uma página.
 */

include("../../acesso/conexao.php");

$sql = "INSERT into cadastros (nome,email,login,senha)
values ('$nome','$email','$login','$senhaI')";

if (mysqli_query($conexao,$sql)) {
    $ok = 1;   // deu certo
} else {
    $ok = 2;    // deu errado
}
//echo $ok;

mysqli_close($conexao);   // fecha a conexão

echo "<script>";
echo "top.window.location = '/exemplo/modulos/exemplo_crud/index.php';";
echo "</script>";


?>