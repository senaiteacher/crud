<?php
$id = trim($_GET["id"]);

include("../../acesso/conexao.php");
include("../../lib/biblioteca.php");

$sql = "SELECT * FROM cadastros WHERE idcadastros='$id'";  // busca exata

$cursor = mysqli_query($conexao,$sql);

if ($cursor) {
    $ok = 1;   // deu certo
    $dados = mysqli_fetch_array($cursor);    // transfere o cursor do MySQL para uma matriz em php chamada $dados
    echo "Codigo do Cadastro: " . $dados[0] . "<BR>";   // envia para a pagina o codigo do cadastro para informação 
} else {
    $ok = 2;    // deu errado
}
//echo $ok;

mysqli_close($conexao);   // fecha a conexão

ativarBoots(); // ativa o bootstrap e dependencias automaticamente

?>

<HTML>
   <BODY>
    <DIV class="container">
        <FORM action="../php/editar.php">
                    <input type="HIDDEN"                         name="id" 		value="<?php echo $dados[0] ?>"><BR>
            Nome :  <input type="TEXT"     class="form-control"  name="nomeCompleto"    value="<?php echo $dados[1] ?>"><BR>
            Email:  <input type="email"    class="form-control"  name="email" 		value="<?php echo $dados[2] ?>"><BR>
            Login:  <input type="TEXT"     class="form-control"  name="login" 		value="<?php echo $dados[3] ?>"><BR>
            Senha:  <input type="password" class="form-control"  name="senha" 		value="<?php echo $dados[4] ?>"><BR>
                    <input type="submit"                                                value="Confirmar" class='btn btn-success'>
        </FORM>
        <BUTTON class='btn btn-warning'  onclick="top.window.location = '/exemplo/modulos/exemplo_crud/index.php';">Cancelar</BUTTON>

    </DIV>
   </BODY>
</HTML>