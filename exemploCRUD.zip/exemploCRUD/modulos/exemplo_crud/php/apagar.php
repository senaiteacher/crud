<?php
$id =  trim($_GET["id"]);

include("../../acesso/conexao.php");

$sql = "DELETE FROM cadastros WHERE idcadastros='$id'";  // Apagar utilizando uma busca exata

$cursor = mysqli_query($conexao,$sql);

if ($cursor) {
	$ok=1;   // deu certo
}else {
	$ok=2;    // deu errado
}
//echo $ok;

mysqli_close($conexao);   // fecha a conexão

echo "<script>";
echo "top.window.location = '/exemplo/modulos/exemplo_crud/index.php';";
echo "location.reload(true);";
echo "</script>";

?>
