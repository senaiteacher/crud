<?php

// Usamos o comando $_GET[] para receber os dados enviados do formulario
// Usamos o comando trim() para limpar os espaços das informações.
$id    = trim($_GET["id"]);
$nome  = trim($_GET["nomeCompleto"]);
$email = trim($_GET["email"]);
$login = trim($_GET["login"]);
$senhaE = trim($_GET["senha"]);

include("../../acesso/conexao.php");

$sql = "UPDATE cadastros set nome='$nome',email='$email',login='$login',senha='$senhaE'
where idcadastros='$id'";

echo $sql;

if (mysqli_query($conexao,$sql)) {
    $ok = 1;   // deu certo
} else {
    $ok = 2;    // deu errado
}
echo $ok;

mysqli_close($conexao);   // fecha a conexão

echo "<script>";
//echo "top.window.location = '/exemplo/modulos/exemplo_crud/index.php';";
echo "</script>";
?>