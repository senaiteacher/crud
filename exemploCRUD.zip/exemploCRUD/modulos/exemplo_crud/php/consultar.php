<?php
include("../../lib/biblioteca.php");

if (isset($_GET["busca"])) {
    $busca = validarEnvio($_GET["busca"]);
} else {
    $busca = '';
}

if (isset($_GET["exato"])) {
    $exato = validarEnvio($_GET["exato"]);
} else {
    $exato = '';
}

if ($busca) {
    if ($exato) {
        $sql = "SELECT * FROM cadastros WHERE nome='$busca'";  // busca exata
    } else {
        $sql = "SELECT * FROM cadastros WHERE nome like '%$busca%'"; // % é REGEX
    }
} else {
    $sql = "SELECT * FROM cadastros";
}

$resposta = executarSQL($sql);

if ($resposta) {
    
    ativarBoots();
    // criar loop para extrair informações do cursor
    echo '<div class="table-responsive">';
    echo "<TABLE class='table'>";
    echo "<TR>";
    echo "<TH>ID</TH>";
    echo "<TH>Nome</TH>";
    echo "<TH>Email</TH>";
    echo "<TH>Login</TH>";
    echo "<TH>Senha</TH>";
    echo "<TH></TH>";
    echo "<TH></TH>";
    echo "</TR>";

    while ($linha = mysqli_fetch_array($resposta)) {
        echo "<TR>";
        echo "<TD>" . $linha[0] . "</TD>";
        echo "<TD>" . $linha[1] . "</TD>";
        echo "<TD>" . $linha[2] . "</TD>";
        echo "<TD>" . $linha[3] . "</TD>";
        echo "<TD>" . $linha[4] . "</TD>";
        
        $linkE = "formEditar.php?id=" . $linha[0]; // link para editar

        echo "<TD><BUTTON class='btn btn-success' onclick='window.document.location.href=" . '"' . $linkE . '"' . "'>Editar</BUTTON></TD>";
        
        $linkD = "apagar.php?id=" . $linha[0];  // link para apagar

        echo "<TD><BUTTON name='btnApagar' class='btn btn-danger' data-toggle='confirmation' data-placement='top' onclick='window.document.location.href=" . '"' . $linkD . '"' . "'>Apagar</BUTTON></TD>";
        
        echo "</TR>";
    }
    echo "</TABLE>";
    echo '</div>';
    $ok = 1;   // deu certo
} else {
    $ok = 2;    // deu errado
}
//echo $ok;
?>