<?php
 //   include("/modulos/acesso/conectar.php"); // inclui o modulo que testa a primeira conexão
 //   $problemaAcesso='';                      // variavel de teste
 //   if(!testarConexao(){                   // realiza o teste da conexao
 //       $problemaAcesso=mysql_error();       // armazena o erro para uso futuro
  //  };
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Exemplo CRUD</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/exemplo/css/bootstrap.min.css">
    <link rel="stylesheet" href="/exemplo/css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="/exemplo/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="/exemplo/css/estilos.css">
  </head>
  <body>

       <div class="container-fluid">
	<div class="row">
            <div class="col-md-12">
		<nav class="navbar navbar-default" role="navigation">
                    <div class="navbar-header">			 
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Trocar navegação</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
			</button> <a class="navbar-brand" href="#">Logomarca</a>
                    </div>
				
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="/exemplo/index.html">Home</a></li>
                            <li><A href="html/incluir.html"  target="principal">Incluir</A> </li>
        
                           
                        </ul>
                    
                        <form class="navbar-form navbar-left" role="search" action="php/consultar.php" target="principal">
                            <div class="form-group">
                                <input class="form-control" type="text" name="busca"/>
                            </div> 
                            <div  class="btn-group" data-toggle="buttons">
                            <label class="btn btn-primary">
                                <input type="checkbox" autocomplete="off" name="exato">exata
                            </label>
                            </div>
                       
                            <button type="submit" class="btn btn-default">Consultar</button>
                            
                            
                        </form>
                    </div>
                </nav>

            <div class="jumbotron">
                <div class="container">
                   <div class="embed-responsive embed-responsive-16by9">
                     <iframe class="embed-responsive-item" name="principal" src="php/consultar.php"></iframe>
                   </div>
                </div>
            </div>
        </div>
   </div>
    
   
     <hr>

      <footer>
        <p>&copy; 2016 Senai Santa Catarina</p>
      </footer>
    </div> <!-- /container -->
  <!-- scripts em javascript são carregados no final --> 
  <script src="/exemplo/js/jquery.min.js"></script>
  <script src="/exemplo/js/bootstrap.min.js"></script>
  <script src="/exemplo/js/metodos.js"></script>
  </body>
</html>

   