<?php
include('parserSQL.php');
include('../lib/biblioteca.php');
/*
 * Ler arqivo texto .sql contendo a estrutura que deseja que seja criada.
 * O arquivo possui o script para a estrutura de acesso e modulo de exemplo.
 * para compatibilidade com o PHP 7 está sendo usado o MySQLi
 * Caso queira utilizar outro Banco de Dados utilize PDO. 
 */

$sql_query = @fread(@fopen('estrutura.sql', 'r'), @filesize('estrutura.sql')) or die('problema com o arquivo SQL.');
$sql_query = remove_remarks($sql_query);
$sql_query = split_sql_file($sql_query, ';');

// Conexão com o MySQL.
include('../acesso/conexao.php');

ativarBoots(); // ativa bootstrap

 echo '<div class="table-responsive">';
 echo "<TABLE class='table'>";
 echo "<TR>";
 echo "<TH>Comando SQL</TH>";
 echo "<TH>Situação</TH>";
 echo "</TR>";

foreach($sql_query as $sql){
     echo "<TR>";
     echo "<TD>".$sql."</TD>";
    if (mysqli_query($conexao,$sql)){
        echo "<TD class='btn btn-success'> Sucesso! </TD>";
    } else {
        echo "<TD class='btn btn-danger'> Erro: ".mysql_error()."</TD>";
    }
 echo "</TR>";
    
    
    }
echo "</table>";
echo "<br><hr>";
?>